 
 <!--<div class="site-section bg-light">-->
  <!--<section class="section testimonial-section">-->
   <section class="w3ls-bnrbtm py-5" id="about">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-7 section-heading">
            
           <h1 class="heading" data-aos="fade-up" style="font-weight:bold">People Says</h1>
          </div>
        </div>
        <div class="row">
		                
 
              <div class="col-md-6 col-lg-4">
			   <div class="testimonial text-center slider-item">
                <div class="author-image mb-3">
                  <img src="admin/images/review/person_1.jpg" alt="Image placeholder" class="rounded-circle"  width="300" height="300">
                </div>
                <blockquote>

                  <p>&ldquo;A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.&rdquo;</p>
                </blockquote>
                <p><em>&mdash; Jean Smith</em></p>
              </div> 
			  </div>
			  
			  <div class="col-md-6 col-lg-4">
			    <div class="testimonial text-center slider-item">
                <div class="author-image mb-3">
                  <img src="admin/images/review/person_2.jpg" alt="Image placeholder" class="rounded-circle"  width="300" height="300">
                </div>
                <blockquote>
                  <p>&ldquo;Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.&rdquo;</p>
                </blockquote>
                <p><em>&mdash; hanna baker</em></p>
              </div>
			  </div>
			  <div class="col-md-6 col-lg-4">
			                <div class="testimonial text-center slider-item">
                <div class="author-image mb-3">
                  <img src="admin/images/review/person_3.jpg" alt="Image placeholder" class="rounded-circle" width="300" height="300">
                </div>
                <blockquote>

                  <p>&ldquo;When she reached the first hills of the Italic Mountains, she had a last view back on the skyline of her hometown Bookmarksgrove, the headline of Alphabet Village and the subline of her own road, the Line Lane.&rdquo;</p>
                </blockquote>
                <p><em>&mdash; John doe</em></p>
              </div>
			  </div>
			  </div>
      </div>
   </section>

 
<!--<section class="section testimonial-section">
        <div class="container">
          <div class="row justify-content-center text-center mb-5">
            <div class="col-md-7">
              <h2 class="heading" data-aos="fade-up">People Says</h2>
            </div>
          </div>
          <div class="row">
            <div class="js-carousel-2 owl-carousel mb-5" data-aos="fade-up" data-aos-delay="200">
              
              <div class="testimonial text-center slider-item">
                <div class="author-image mb-3">
                  <img src="admin/images/review/person_1.jpg" alt="Image placeholder" class="rounded-circle mx-auto">
                </div>
                <blockquote>

                  <p>&ldquo;A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.&rdquo;</p>
                </blockquote>
                <p><em>&mdash; Jean Smith</em></p>
              </div> 

              <div class="testimonial text-center slider-item">
                <div class="author-image mb-3">
                  <img src="admin/images/review/person_2.jpg" alt="Image placeholder" class="rounded-circle mx-auto">
                </div>
                <blockquote>
                  <p>&ldquo;Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.&rdquo;</p>
                </blockquote>
                <p><em>&mdash; John Doe</em></p>
              </div>

              <div class="testimonial text-center slider-item">
                <div class="author-image mb-3">
                  <img src="admin/images/review/person_3.jpg" alt="Image placeholder" class="rounded-circle mx-auto">
                </div>
                <blockquote>

                  <p>&ldquo;When she reached the first hills of the Italic Mountains, she had a last view back on the skyline of her hometown Bookmarksgrove, the headline of Alphabet Village and the subline of her own road, the Line Lane.&rdquo;</p>
                </blockquote>
                <p><em>&mdash; John Doe</em></p>
              </div>


              <div class="testimonial text-center slider-item">
                <div class="author-image mb-3">
                  <img src="admin/images/review/person_1.jpg" alt="Image placeholder" class="rounded-circle mx-auto">
                </div>
                <blockquote>

                  <p>&ldquo;A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth.&rdquo;</p>
                </blockquote>
                <p><em>&mdash; Jean Smith</em></p>
              </div> 

              <div class="testimonial text-center slider-item">
                <div class="author-image mb-3">
                  <img src="admin/images/review/person_2.jpg" alt="Image placeholder" class="rounded-circle mx-auto">
                </div>
                <blockquote>
                  <p>&ldquo;Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.&rdquo;</p>
                </blockquote>
                <p><em>&mdash; John Doe</em></p>
              </div>

              <div class="testimonial text-center slider-item">
                <div class="author-image mb-3">
                  <img src="admin/images/review/person_3.jpg" alt="Image placeholder" class="rounded-circle mx-auto">
                </div>
                <blockquote>

                  <p>&ldquo;When she reached the first hills of the Italic Mountains, she had a last view back on the skyline of her hometown Bookmarksgrove, the headline of Alphabet Village and the subline of her own road, the Line Lane.&rdquo;</p>
                </blockquote>
                <p><em>&mdash; John Doe</em></p>
              </div>

            </div>
              <!-- END slider -->
          <!--</div>

        </div>
      </section>-->
 