<html>
<head>
<title>form</title>
</head>
<body>
<form>
<table>

<tr>
<td>Add images</td>
<td><input type="file" name="Add images"></td>
</tr>
</table>
</form>
</body>
</html>