<?php/*--php multiple line comment---*/
// php single line comment
?>
<!--html comment -->